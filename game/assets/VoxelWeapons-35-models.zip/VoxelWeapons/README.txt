35 original stylized real-world-inspired voxel firearms. Related variants share family geometry.
Roblox: insert .rbxmx using Insert from File. These exports are anchored display models without scripts.
OBJ: import .obj with its matching .mtl for color. Units: Roblox studs; +X forward, +Y up.
The Luau builders provide component metadata, muzzle/grip attachments, and mounting for gameplay.
All models are original approximations, not engineering replicas. No game-runtime or Studio testing claimed.
